# SPECS — Normative Requirements (consolidated)

This file is a verbatim consolidation of the six normative spec deltas at
`openspec/changes/add-payout-plugins/specs/` in `github.com/A-Mannan/spawn-contracts`.
Nothing here is paraphrased or added. The repository is the source of truth: if this file and
the repo disagree, the repo wins.

Headers reading `## MODIFIED Requirements`, `## ADDED Requirements`, or `## REMOVED Requirements`
are openspec delta markers relative to the superseded `add-milestone-launchpad` change; the
requirement text below each header is the current, authoritative requirement. `#### Scenario:`
names are the contract with the protocol's test suite.

---

# Capability: graduation

## MODIFIED Requirements

### Requirement: Bonding curve proceeds split
Graduation SHALL retain the immutable 20% locked-LP seed, 70% direct creator, and 10% protocol split. The protocol share SHALL enter the single global protocol ledger with source-pool attribution; the creator share SHALL enter the pool's direct RevenueNFT ledger. Administrative economic updates SHALL NOT change this graduation split. Unbought curve token inventory and curve token fees SHALL return to ladder inventory.

#### Scenario: Default split is applied
- **WHEN** graduation completes
- **THEN** 20% seeds locked liquidity, 70% credits direct creator revenue, and 10% credits the global protocol ledger

#### Scenario: Protocol graduation revenue accrues globally
- **WHEN** any pool graduates
- **THEN** its protocol share increases the pool-agnostic protocol balance and emits source-pool attribution

#### Scenario: Economic updates do not alter graduation split
- **WHEN** the administrator changes service-fee or swap-fee distributions
- **THEN** future graduations still use 20 70 10

#### Scenario: Curve tokens become ladder inventory
- **WHEN** graduation releases unbought token inventory or token-denominated curve fees
- **THEN** those tokens remain in protocol custody for bands and never become claimant revenue

#### Scenario: Graduation allocations conserve proceeds
- **WHEN** graduation quote proceeds are split
- **THEN** LP seed, direct creator credit, and global protocol credit equal collected quote proceeds up to specified rounding dust

#### Scenario: Creator proceeds are not pushed
- **WHEN** graduation completes
- **THEN** creator quote value is credited for pull claiming rather than transferred

## ADDED Requirements

### Requirement: Post-graduation full-range position remains fixed
Graduation SHALL continue to seed the initial permanently locked full-range position from the immutable launch token allocation and quote seed. After graduation, payout proceeds and collected quote or token fees SHALL NOT add liquidity to that position or create LP carry. Token-fee burning, milestone funding, payout flushing, and direct or global claiming SHALL NOT reduce the existing locked position.

#### Scenario: Graduation seeds both sides from original allocations
- **WHEN** graduation completes
- **THEN** the locked position uses the immutable token allocation and 20% quote seed

#### Scenario: Quote fees do not compound
- **WHEN** quote fees are collected after graduation
- **THEN** they route only between direct creator and global protocol revenue

#### Scenario: Token fees do not compound
- **WHEN** token fees are collected after graduation
- **THEN** they only fund future bands or burn

#### Scenario: Payouts do not compound
- **WHEN** a milestone payout pot is flushed
- **THEN** no payout destination adds liquidity through a protocol-authored LP plugin

#### Scenario: No LP fee carry exists
- **WHEN** any fee collection or payout flush completes
- **THEN** no quote or token amount is retained for later liquidity compounding

#### Scenario: Other routing preserves existing liquidity
- **WHEN** fees burn, fund milestones, accrue claims, or flush to plugins
- **THEN** the initial full-range position remains unchanged and non-withdrawable

# Capability: milestone-ladder

## MODIFIED Requirements

### Requirement: Harvest detection and atomic settlement
The system SHALL detect milestone completion in the same transaction as the crossing swap. When the post-swap level is at or above a deployed incomplete band's upper level, the band SHALL be marked complete, its position burned, and its released quote proceeds and fees accounted before the transaction ends. The harvest SHALL record the gross amount, accrue the active global service fee, and fund the pool's payout pot with the exact remainder. It SHALL NOT redeem the pot, transfer ETH, invoke a payout plugin, perform a buyback, or add liquidity. Harvest work SHALL remain capped per swap.

#### Scenario: Crossing the band top completes and accounts for the milestone
- **WHEN** a swap ends at or above a deployed incomplete band's upper level
- **THEN** the band is completed and burned, its gross proceeds are recorded, and service-fee and pot accounting finish atomically

#### Scenario: Partial fill does not complete the milestone
- **WHEN** a swap ends inside a deployed band's range
- **THEN** the band remains incomplete and no service fee or payout-pot value accrues for it

#### Scenario: Band swap fees fold into the gross harvest
- **WHEN** a harvested band has accrued fees
- **THEN** those fees are included in the milestone's recorded gross quote amount

#### Scenario: A sweeping swap accounts for every completed band within the cap
- **WHEN** one swap ends above several deployed band tops within the harvest cap
- **THEN** each band is completed and accounted in ascending order with distinct milestone attribution

#### Scenario: Harvests beyond the cap remain pending
- **WHEN** one swap crosses more deployed bands than the harvest cap
- **THEN** excess bands remain deployed and unharvested until a later eligible swap

#### Scenario: A completed band cannot be accounted again
- **WHEN** a later swap ends above an already completed band
- **THEN** no additional harvest, service fee, or pot credit occurs for that band

#### Scenario: Harvest invokes no payout plugin
- **WHEN** any band is harvested during a swap
- **THEN** neither swap callback invokes a payout plugin or redeems a payout pot

### Requirement: Harvest proceeds routing
For each gross quote harvest, the system SHALL credit the active globally configured service-fee percentage to the single protocol ledger and credit the exact remainder to only the source pool's payout pot. The service fee SHALL default to 10% and SHALL be subject to the immutable governance cap specified by the payout-plugin capability. Harvest SHALL NOT directly credit creator revenue, buy back tokens, or compound liquidity. Token residue SHALL return to carried ladder inventory. Events SHALL preserve the milestone index, gross amount, active configuration version, service fee, and net pot credit.

#### Scenario: Gross harvest is attributed before deductions
- **WHEN** a milestone is harvested
- **THEN** its pool, index, and gross quote amount are observable independently of later payout settlement

#### Scenario: Active service fee is applied
- **WHEN** a milestone is harvested after an economic update executes
- **THEN** that operation uses one snapshot of the active service-fee percentage and configuration version

#### Scenario: Net harvest funds only its source pool
- **WHEN** the service fee is deducted
- **THEN** the exact gross remainder increases only the source pool's payout pot

#### Scenario: Harvest proceeds are quote only
- **WHEN** a band is harvested
- **THEN** routed proceeds are quote currency and any token residue returns to carried inventory

#### Scenario: Harvest accounting conserves the gross amount
- **WHEN** harvest accounting completes
- **THEN** service fee plus net pot credit equals the gross quote amount exactly

#### Scenario: Harvest leaves direct creator revenue unchanged
- **WHEN** a milestone is harvested
- **THEN** the hook's direct creator-revenue ledger is unchanged

#### Scenario: Harvest performs no direct destination work
- **WHEN** a milestone is harvested
- **THEN** no creator payment, buyback, liquidity operation, or plugin delivery occurs

### Requirement: The hook never blocks a swap in the graduated phase
The system SHALL permit swaps in both directions at every price after graduation. Bounded band deployment and harvest accounting MAY occur as swap side effects, but pot redemption and payout delivery SHALL never be implicit swap work. Only a caller that explicitly selects the swap-and-flush helper MAY compose a settled swap with a later cold flush.

#### Scenario: Swaps succeed in both directions
- **WHEN** a trader swaps in either direction after graduation
- **THEN** the swap succeeds subject only to ordinary pool liquidity and price limits

#### Scenario: In-band oscillation cannot prevent completion
- **WHEN** traders move repeatedly through a partially filled band
- **THEN** its state remains consistent and it completes when an eligible swap ends above its top

#### Scenario: Ordinary swaps never flush
- **WHEN** a trader uses an ordinary router
- **THEN** no payout pot is redeemed and no payout plugin is invoked

#### Scenario: Plugin availability cannot block a swap
- **WHEN** any selected payout plugin is reverting, suspended, or out of gas
- **THEN** an ordinary swap and its bounded harvest accounting remain executable

## ADDED Requirements

### Requirement: The decaying schedule, bounded seed, and wall reserve
The template SHALL define the ladder schedule as a first step above graduation that decays by a fixed per-step level amount to the floor spacing: band `i+1` SHALL start `max(bandLevelSpacing, bandFirstStepLevels - bandStepDecayLevels * i)` levels above band `i`, and the fee-funded extensions SHALL continue at the floor spacing. Launch supply SHALL be pinned to the protocol constant so the seeded positions' bounds are protocol constants too. Graduation SHALL seed the full-range position over the template's bounded market-cap range from the LP seed share, and SHALL place every token the seed does not consume into a single-sided wall position spanning the levels directly above graduation. The wall SHALL hold no quote currency at mint, SHALL have no removal path anywhere in the protocol, and SHALL realise its accrued quote fees through the same collection waterfall as the full-range position. The deployment walk SHALL price the wall's liquidity into the simulated swap path.

#### Scenario: The schedule decays from a wide first step to the floor spacing
- **WHEN** an observer computes band bounds from the template and the graduation level alone
- **THEN** the steps follow the decaying schedule, lock at the floor spacing, and agree with the library's closed form

#### Scenario: Graduation seeds the bounded full range and its wall
- **WHEN** graduation seeds the pool
- **THEN** the full-range position spans the bounded range and consumes the whole seed on the quote side, the wall absorbs the unconsumed token share with no quote charged, and the residue is rounding dust only

#### Scenario: Realised wall fees join the same waterfall
- **WHEN** a collection realises fees after trades through the wall's range
- **THEN** the wall's quote fees route through the same waterfall as the full-range position's and the wall's liquidity is unchanged

#### Scenario: The deployment walk prices the wall in
- **WHEN** the hook simulates a buy too small to reach the ladder through the wall's liquidity
- **THEN** no band deploys, because the walk's budget is consumed before the first band's lower bound

## REMOVED Requirements

### Requirement: Settlement is reentrancy-guarded
**Reason**: Harvest no longer performs nested buyback or liquidity settlement. Payout-specific reentrancy, callback suppression, failure isolation, and recovery are defined by the new `payout-plugins` capability.

**Migration**: Replace harvest-settlement tests with payout-plugin lock, callback-suppression, carry, and drain-protection scenarios.

# Capability: payout-plugins

## Purpose

Define immutable launch-selected payout destinations and permissionless cold settlement without allowing plugin failures, governance updates, or custody interactions to block swaps or drain unrelated protocol value.

## ADDED Requirements

### Requirement: Append-only payout-plugin registry
The protocol SHALL reference one registry whose plugin indices, addresses, fixed takes, gas limits, and roles remain stable after registration. The registry SHALL contain at most 256 entries, SHALL reject duplicate or invalid registrations, and SHALL permit mutations only through the typed ProtocolController. Immediately before any registry-only mutation, the controller SHALL query the hook's protocol-global payout-delivery guard and SHALL revert while delivery is in flight. Suspension SHALL be reversible without changing the entry's index or terms. New launches SHALL NOT select a suspended entry; an existing plan's current share and carry for a suspended entry SHALL route to the creator sink until reactivation. Runtime codehash mismatch SHALL permanently redirect that attempt's current share plus all carry to the creator path without calling the entry; restoring code or appending a replacement SHALL NOT replay redirected value. Reactivation SHALL restore the immutable destination for later allocations but SHALL NOT recover value already redirected.

#### Scenario: Registration appends at a stable index
- **WHEN** the administrator registers a valid plugin
- **THEN** it is appended at the next index and every earlier index remains unchanged

#### Scenario: Registered terms cannot change
- **WHEN** a registry entry exists
- **THEN** its address, fixed take, gas limit, role, and index cannot be edited, removed, or reordered

#### Scenario: Registry is bounded to one word
- **WHEN** the administrator attempts to register a 257th entry
- **THEN** registration is rejected

#### Scenario: Unauthorized registry mutation is rejected
- **WHEN** an address other than the administrator attempts registration or suspension
- **THEN** the operation is rejected

#### Scenario: Suspension preserves identity
- **WHEN** the administrator suspends and later reactivates an entry
- **THEN** its stable index and immutable terms are unchanged

#### Scenario: Suspended value redirects to the creator
- **WHEN** an enabled entry is suspended with a current share or failed carry
- **THEN** that value is assigned to the creator sink and other plan destinations remain unaffected

#### Scenario: Reactivation affects later allocations only
- **WHEN** a suspended entry is reactivated after value was redirected
- **THEN** later plan allocations use the entry again and prior redirection is not reversed

#### Scenario: Registry mutation is blocked during payout delivery
- **WHEN** a typed registry operation executes while the hook-global payout guard is held
- **THEN** the controller's execution reverts before the registry changes

#### Scenario: Codehash mismatch permanently redirects value
- **WHEN** an enabled entry's live codehash differs while it has a current share or carry
- **THEN** the entry is not called, its complete attempted amount credits the creator path, its carry clears, and later code restoration cannot replay that amount

### Requirement: Protocol administration and delayed updates
The protocol SHALL maintain a configurable administrator distinct from the configurable protocol revenue recipient. Only the administrator SHALL control registry registration and suspension, economic configuration, revenue-recipient updates, and governance-delay updates. Administrator transfer SHALL use a two-step propose-and-accept process in which only the pending administrator can accept. Administrative configuration changes SHALL be typed, scheduled, cancellable before execution, and executable only after the active delay. The initial delay SHALL be zero seconds and MAY later change through the same delayed mechanism; already scheduled operations SHALL retain their original readiness. The protocol SHALL support a multisig as administrator without assuming signer policy on chain. The administrator SHALL have no implicit right to claim protocol revenue.

#### Scenario: Administrator and recipient are independent
- **WHEN** distinct addresses are configured
- **THEN** administrative authority does not grant claim authority and recipient status does not grant governance authority

#### Scenario: Administrator transfer requires acceptance
- **WHEN** the administrator proposes a non-zero successor
- **THEN** authority changes only after that exact pending address accepts

#### Scenario: Unauthorized acceptance is rejected
- **WHEN** an address other than the pending administrator attempts acceptance
- **THEN** the operation reverts and current authority remains unchanged

#### Scenario: Zero-delay update can execute immediately
- **WHEN** an authorized operation is scheduled while delay is zero
- **THEN** it may execute in the same transaction or multisig batch after scheduling

#### Scenario: Positive delay is enforced
- **WHEN** the delay has been increased and an operation is executed before readiness
- **THEN** execution is rejected

#### Scenario: Delay update uses the old delay
- **WHEN** the administrator schedules a new delay
- **THEN** that update cannot execute earlier than the delay active at scheduling

#### Scenario: Queued readiness does not change retroactively
- **WHEN** the governance delay changes after an operation was scheduled
- **THEN** the operation retains its original ready time

#### Scenario: Scheduled operation can be cancelled
- **WHEN** the administrator cancels a pending operation before execution
- **THEN** that operation can no longer execute

#### Scenario: Operation identity binds complete parameters
- **WHEN** any scheduled parameter, action type, controller identity, chain, or salt differs at execution
- **THEN** it does not match the queued operation

### Requirement: Immutable signed bitset payout plans
Each launch SHALL store the exact signed 256-bit payout plan. A set bit SHALL select the plugin at that stable registry index; a zero bit SHALL not select it. At launch, every selected entry SHALL exist, be active, have a selectable payout role, and the fixed takes SHALL total at most one whole. A launch SHALL enable at most eight payout plugins. The creator sink SHALL be implicit and always active, and SHALL receive all post-tip distributable value not allocated to selected active plugins, including fixed-point dust. The plan SHALL have no mutable percentages or on-chain preset name and SHALL never change after launch.

#### Scenario: Set bits select stable registry indices
- **WHEN** a valid plan is launched
- **THEN** each set bit selects exactly the entry at that index

#### Scenario: Invalid plan bits are rejected
- **WHEN** a plan selects an unregistered, suspended, or non-payout entry
- **THEN** launch is rejected

#### Scenario: Excessive fixed takes are rejected
- **WHEN** selected fixed takes total more than one whole
- **THEN** launch is rejected

#### Scenario: Enabled plugin count is bounded
- **WHEN** a plan contains more than eight selectable set bits
- **THEN** launch is rejected

#### Scenario: Empty plan pays the creator
- **WHEN** a launch selects no payout plugin
- **THEN** the creator sink receives the entire post-tip distributable amount

#### Scenario: Creator receives allocation dust
- **WHEN** fixed-point division leaves an unallocated remainder
- **THEN** the remainder is assigned to the creator sink

#### Scenario: Plan cannot change after launch
- **WHEN** a pool has launched
- **THEN** no caller can update its payout-plan bits

#### Scenario: Registry growth cannot reinterpret a plan
- **WHEN** entries are appended after a pool launches
- **THEN** every existing set bit retains its original meaning

#### Scenario: Preset names are off chain
- **WHEN** two off-chain preset names resolve to identical bits
- **THEN** they produce identical on-chain plan data

### Requirement: Isolated harvest payout pots and attribution
Each pool SHALL have an isolated payout pot containing net milestone proceeds not yet allocated by a flush. A harvest SHALL record pool, milestone index, and gross quote amount; deduct the active global service-fee percentage into the global protocol ledger and its exact claim-backed subset; and credit the exact remainder to only that pool's pot. Multiple milestones MAY aggregate in one pot while their event history remains reconstructible. The hook SHALL maintain exact aggregate counters for payout pots, plugin carry, creator-path entitlement, direct creator claims, global protocol claims, and the claim-backed subset of global protocol claims, updated atomically with their component ledgers. The claim-backed protocol subset SHALL never exceed the global protocol ledger. Outside active liability-class redemption, redeemable quote claims SHALL cover aggregate pots plus claim-backed protocol revenue, while raw ETH SHALL cover carry, creator-path, direct creator, and the non-claim-backed protocol remainder; combined raw ETH and claims SHALL cover their sum. Pot redemption SHALL consume only pot backing. A global protocol claim SHALL redeem exactly its captured claim-backed subset and SHALL NOT consume pot backing. The protocol SHALL NOT maintain an on-chain per-milestone tranche ledger.

#### Scenario: Gross harvest is attributable
- **WHEN** a band is harvested
- **THEN** an event records its pool, milestone index, and gross quote amount before deductions

#### Scenario: Service fee precedes pot funding
- **WHEN** gross harvest proceeds are accounted
- **THEN** the active service fee enters the global protocol ledger and the exact remainder enters the source pool's pot

#### Scenario: Pots are isolated across pools
- **WHEN** multiple pools accrue and flush milestone proceeds
- **THEN** no pool can consume another pool's pot

#### Scenario: Multiple milestones aggregate without losing history
- **WHEN** several milestones fund one pot before a flush
- **THEN** the pot aggregates their net value and events preserve each milestone's attribution

#### Scenario: Mid-swap pot and service-fee accrual remain solvent
- **WHEN** a harvest accrues while PoolManager settlement is in flight
- **THEN** its pot and protocol service fee are both classified as claim-backed without requiring premature ETH redemption

#### Scenario: Aggregate liabilities equal component ledgers
- **WHEN** harvest, flush, failure, redirect, or claim changes any payout liability
- **THEN** each aggregate counter equals the sum of its recorded component ledgers and claim-backed protocol revenue does not exceed the global protocol ledger

#### Scenario: Custody classes cover their liabilities
- **WHEN** no liability-class redemption unlock is active
- **THEN** redeemable quote claims cover aggregate pots plus claim-backed protocol revenue, raw ETH covers carry and claimable ledgers excluding that claim-backed subset, and combined custody covers total ETH liabilities

#### Scenario: Protocol claim redeems only protocol backing
- **WHEN** global protocol revenue includes claim-backed service fees while payout pots coexist
- **THEN** the recipient's claim redeems exactly the protocol-backed subset and leaves every payout pot fully claim-backed

### Requirement: Permissionless whole-pot cold flush
Any address SHALL be able to flush one pool. A flush SHALL remove the complete newly accrued pot from available accounting before external calls, redeem it exactly once — alone or together with other pools' pots in one shared PoolManager unlock — and perform delivery outside all swap callbacks. The flusher tip SHALL equal the floor of 1% of the newly redeemed post-service-fee pot. An ordinary flush SHALL transfer that tip before plugin delivery to the caller-provided tip recipient, and failure of that transfer SHALL revert the complete flush atomically. Plan takes SHALL apply to the remaining 99%. Previously failed carry SHALL be retried without another tip. A batch flush over many pools SHALL share one redemption unlock and one combined tip transfer to the batch's tip recipient, SHALL zero every pot before any delivery, SHALL attribute each pot's redemption and tip per pool, and SHALL be all-or-nothing: any pool's unrecoverable failure reverts the complete batch with every pool's accounting unchanged.

#### Scenario: Any address can flush one pool
- **WHEN** an arbitrary caller requests a flush for a valid pool
- **THEN** the protocol processes that pool without requiring creator or administrator authorization

#### Scenario: Whole new pot is redeemed once
- **WHEN** a pool has newly accrued pot value
- **THEN** the complete new pot is redeemed exactly once and the pot is zeroed before delivery

#### Scenario: Flusher receives one percent of the net new pot
- **WHEN** a new pot is flushed
- **THEN** the directed tip recipient receives floor(new pot times 1%) and plan allocations use the remainder

#### Scenario: A batch redeems every pot in one unlock
- **WHEN** a batch flushes several pools with accrued pots
- **THEN** one shared unlock redeems the complete total and each pot is zeroed before delivery

#### Scenario: Batch tips transfer once
- **WHEN** a batch flushes several pools
- **THEN** each pool's tip is attributed per pot and the combined tips reach the recipient in one transfer

#### Scenario: A batch is all-or-nothing
- **WHEN** any pool in a batch fails unrecoverably
- **THEN** the complete batch reverts with every pool's pot, carry, liabilities, plugin state, events, and transfers unchanged

#### Scenario: Protocol service fee is never tipped
- **WHEN** a gross harvest is later flushed
- **THEN** the tip excludes the service fee already credited to the protocol

#### Scenario: Carry is not tipped twice
- **WHEN** a previous failed share is retried
- **THEN** no new tip is deducted from that carry

#### Scenario: Carry-only flush remains available
- **WHEN** no new pot exists but failed carry exists
- **THEN** a caller can retry delivery with a zero tip

#### Scenario: Empty flush is a no-op
- **WHEN** neither new pot nor carry exists
- **THEN** the call performs no unlock or value transfer

#### Scenario: Ordinary flusher tip failure is atomic
- **WHEN** an ordinary flush cannot transfer the 1% tip to the directed recipient
- **THEN** the complete flush reverts with pot, carry, liabilities, plugin state, events, and transfers unchanged

#### Scenario: Ordinary swaps do not flush
- **WHEN** a trader uses an ordinary router
- **THEN** no pot is redeemed and no payout plugin is invoked

### Requirement: Stipended and failure-isolated plugin delivery
A flush SHALL process selected destinations in ascending registry-index order. Each active plugin SHALL receive plain ETH equal only to its current computed share plus its own previous carry, under its registered gas limit. Plugin success SHALL be exactly the EVM `CALL` success bit for the void callback `onPayout(PoolId,address)`; the core SHALL ignore all returndata. A zero success bit from revert or gas exhaustion SHALL preserve the full attempted value in a per-pool, per-entry carry ledger and SHALL NOT block later destinations. The published constants SHALL be `CALL_FIXED_GAS = 15_000`, `POST_CALL_GAS = 100_000`, `FINALIZE_GAS = 100_000`, and `MAX_PLUGIN_CALL_GAS = 500_000`, and registration SHALL require `1 <= callGas <= MAX_PLUGIN_CALL_GAS`. At each actual call boundary, `remainingCalls` SHALL include the current call and every unresolved later selected entry. After suspension/codehash resolution, zero-attempt filtering, carry clearing, liability effects, and callback calldata materialization, but before any uncovered call-specific setup, the core SHALL compute `reserve = remainingCalls * POST_CALL_GAS + FINALIZE_GAS` and `eip150Margin = (callGas + 62) / 63`, then require `gasleft() >= reserve + callGas + eip150Margin + CALL_FIXED_GAS`. Failed preflight SHALL revert the complete flush rather than become carry. Successful delivery SHALL clear carry and SHALL NOT be replayable. Delivery events SHALL make successful, carried, and redirected values reconcilable.

#### Scenario: Plugins execute deterministically
- **WHEN** multiple plugins are enabled
- **THEN** delivery attempts occur in ascending registry-index order

#### Scenario: Plugin receives only its allocation
- **WHEN** an active plugin is called
- **THEN** it receives plain ETH equal to its current share plus its own carry and cannot consume another share

#### Scenario: Void callback success ignores returndata
- **WHEN** a plugin's void callback returns with EVM CALL success and any empty, malformed, or non-empty returndata
- **THEN** delivery succeeds, all returndata is ignored, and the attempted amount does not become carry

#### Scenario: EIP-150 preflight preserves finalization gas
- **WHEN** a plugin attempt reaches the call boundary
- **THEN** the exact formula using `15_000` fixed gas, `100_000` per unresolved call, `100_000` finalization gas, and `(callGas + 62) / 63` EIP-150 margin passes before CALL

#### Scenario: Insufficient preflight gas reverts the flush
- **WHEN** gas at a plugin call boundary is below the published preflight formula
- **THEN** the whole flush reverts and no attempted amount is misclassified as plugin carry

#### Scenario: Reverting plugin does not block later plugins
- **WHEN** one plugin reverts
- **THEN** its full attempted amount becomes carry and every later destination is still attempted

#### Scenario: Gas-exhausting plugin is isolated
- **WHEN** a plugin consumes its registered gas allowance
- **THEN** its call fails into carry without exhausting the outer flush gas bound

#### Scenario: Failed carry is retried
- **WHEN** a later flush encounters carry for an active plugin
- **THEN** that carry is added to the plugin's attempted delivery without a second tip

#### Scenario: Successful delivery is not replayed
- **WHEN** a plugin accepts its attempted amount
- **THEN** its carry is cleared and the same value cannot be delivered again

#### Scenario: Flush accounting conserves value
- **WHEN** a flush completes
- **THEN** tip, successful deliveries, creator value, redirects, and remaining carry equal all new pot and retried carry value

### Requirement: Creator payout entitlement
The implicit mandatory creator sink SHALL receive every post-tip amount not allocated to active selected plugins, including rounding dust, suspended-plugin redirects, and codehash-mismatch redirects. The creator path SHALL credit a separate per-pool entitlement ledger without pushing ETH to the holder during an arbitrary flush. Entitlement SHALL belong to the current RevenueNFT owner and SHALL remain distinct from the hook's direct creator-revenue ledger. A creator-path claim SHALL authenticate the initiating owner, flush first, query RevenueNFT ownership again after every plugin interaction, and revert the complete call if ownership changed. It SHALL then attempt the complete entitlement including its self-flush tip. Failure of this final transfer SHALL NOT revert: the complete attempted amount SHALL be restored to creator-path entitlement and aggregate liability, an event SHALL identify pool, holder, attempted amount, and failure, and the call SHALL return explicit `(success, attemptedAmount)` observability. A creator-path claim SHALL also be available as a batch over many pools that shares one redemption unlock, authenticates the caller as every pool's current holder, keeps per-pool ownership rechecks and per-pool final transfers, and reverts the complete batch if any pool's ownership changed; a failed per-pool final transfer SHALL restore only that pool's entitlement and SHALL NOT revert the batch.

#### Scenario: Arbitrary flush records rather than pushes creator value
- **WHEN** a third party flushes a pool
- **THEN** the creator sink credits the pool ledger without transferring ETH to the NFT holder

#### Scenario: Creator value follows NFT ownership
- **WHEN** the RevenueNFT is transferred before creator-path value is claimed
- **THEN** the new holder gains the complete unpaid entitlement and the previous holder loses it

#### Scenario: Creator-path and direct ledgers remain separate
- **WHEN** a flush credits creator remainder
- **THEN** the hook's direct creator ledger is unchanged

#### Scenario: Creator payout flushes first
- **WHEN** the current NFT holder invokes creator-path payout
- **THEN** the creator path first flushes the pool and then attempts the complete resulting entitlement

#### Scenario: Creator self-flush preserves the tip
- **WHEN** the NFT holder initiates creator payout
- **THEN** the 1% tip is included in that initiating holder's complete final transfer

#### Scenario: Ownership change during plugins reverts payout
- **WHEN** RevenueNFT ownership differs after plugin interactions from the owner authenticated at creator-payout entry
- **THEN** the complete flush and payout revert before any creator-path transfer

#### Scenario: A creator batch pays every pool's complete entitlement
- **WHEN** the holder of every pool's RevenueNFT invokes a creator batch over several pools
- **THEN** one shared redemption delivers every pool's pot, and each pool's complete entitlement including its retained tip is attempted for the holder

#### Scenario: Creator batch reverts on ownership change
- **WHEN** any pool's RevenueNFT ownership changes during a creator batch
- **THEN** the complete batch reverts with every pool's accounting unchanged

#### Scenario: Failed recipient transfer preserves entitlement
- **WHEN** the complete creator-path transfer to the current holder fails
- **THEN** the call does not revert, the attempted amount including any self-flush tip is restored in full, and return data and an event report failure and attempted amount

### Requirement: Plugin reentrancy and drain protection
Payout accounting SHALL follow checks-effects-interactions and use transaction-scoped reentrancy control. During plugin delivery, no plugin SHALL re-flush any pool, replay settlement, mutate a different pool, or reach direct creator revenue, global protocol revenue, another pool's pot, another plugin's carry, ladder inventory, or locked liquidity. Pool callbacks caused by an authorized reference plugin interaction SHALL suppress payout and ladder work. A failed nested interaction SHALL leave accounting recoverable, and the guard SHALL not persist across transactions.

#### Scenario: Same-pool reentry is rejected
- **WHEN** a plugin attempts to flush its active pool recursively
- **THEN** the nested operation is rejected without corrupting the outer settlement

#### Scenario: Cross-pool reentry is rejected
- **WHEN** a plugin attempts payout or protocol activity against another pool
- **THEN** the nested operation fails into that plugin's carry

#### Scenario: Unrelated value is unreachable
- **WHEN** a plugin executes
- **THEN** it cannot consume direct or protocol ledgers, other pots or carries, ladder inventory, or locked liquidity

#### Scenario: Nested callbacks suppress protocol work
- **WHEN** a plugin's PoolManager interaction invokes hook callbacks
- **THEN** no ladder deployment, harvest, graduation, fee collection, or payout work begins

#### Scenario: Guard clears after the transaction
- **WHEN** a guarded transaction completes or reverts
- **THEN** a later independent transaction can use the protected entry points

### Requirement: Reference buyback-and-burn plugin
The protocol-authored buyback plugin SHALL accept only hook-authenticated payouts, use only its delivered ETH to buy the source pool's launch token through its own cold PoolManager interaction, and burn every acquired token. If the atomic purchase and burn cannot complete under its immutable execution bounds, the callback SHALL fail so the hook carries the entire attempted share.

#### Scenario: Buyback spends only delivered ETH
- **WHEN** the buyback plugin receives a payout
- **THEN** it cannot spend another pool's funds or unrelated balances

#### Scenario: Buyback burns acquired tokens
- **WHEN** the buyback succeeds
- **THEN** every acquired launch token is burned and total supply falls accordingly

#### Scenario: Failed buyback carries the entire share
- **WHEN** the bounded purchase or burn cannot complete atomically
- **THEN** the plugin call fails and the hook records the full attempted amount as carry

#### Scenario: Zero delivery performs no swap
- **WHEN** the plugin has neither a current share nor carry
- **THEN** it is not invoked

### Requirement: Canonical default plan and off-chain presets
The deployment SHALL publish one canonical default bitset that enables the registered buyback plugin with a fixed take of 2/9 of the post-tip distributable amount. The creator SHALL remain the implicit mandatory sink and receive the exact remainder, nominally 7/9 plus fixed-point dust. With the default 10% service fee, this preserves the former 2:1 buyback-to-LP plugin allocation by redirecting the removed LP destination into the creator remainder. Named presets SHALL remain off-chain aliases only; signatures, CREATE2 identity, and storage SHALL bind the bitset rather than a preset name.

#### Scenario: Canonical bits select intended destinations
- **WHEN** fixtures or frontends use the canonical default
- **THEN** its bits select the published buyback entry and no utility or creator-system entry

#### Scenario: Canonical economics match their declared baseline
- **WHEN** the default service fee and canonical plan process a pot
- **THEN** service fee, tip, creator remainder, and buyback share match the published post-tip baseline

#### Scenario: Preset naming cannot change identity
- **WHEN** an off-chain preset is renamed without changing bits
- **THEN** the signed plan and predicted token address remain unchanged

#### Scenario: Preset bit changes alter identity
- **WHEN** a preset resolves to different plan bits
- **THEN** the signed plan and predicted token address change

# Capability: revenue-claims

## MODIFIED Requirements

### Requirement: Creator accruals are credited to the NFT
Only the creator's share of quote-denominated swap fees and bonding-curve proceeds SHALL be credited to the hook's direct per-pool creator ledger. Milestone proceeds SHALL enter the payout pot and the separate creator-path entitlement ledger instead. All creator entitlements SHALL be quote-denominated and SHALL follow current RevenueNFT ownership; token-denominated fees SHALL never accrue to a claimant.

#### Scenario: Fee creator share accrues directly
- **WHEN** quote-denominated swap fees are collected
- **THEN** the active creator share is added to the pool's direct creator ledger

#### Scenario: Bonding curve creator share accrues directly
- **WHEN** graduation completes
- **THEN** the creator share of bonding-curve proceeds is added to the direct creator ledger

#### Scenario: Token fees never accrue to a claimant
- **WHEN** token-denominated fees are collected
- **THEN** neither creator nor protocol claimable revenue increases from those tokens

#### Scenario: Direct creator sources aggregate
- **WHEN** swap-fee and bonding-curve creator revenue accrues without a claim
- **THEN** the direct creator ledger equals the sum of those sources

#### Scenario: Milestone harvest does not credit direct creator revenue
- **WHEN** a milestone is harvested or its pot is flushed
- **THEN** no milestone value is added to the hook's direct creator ledger

#### Scenario: Plugin-pot proceeds remain separate
- **WHEN** creator remainder is assigned to the creator path
- **THEN** it is accounted in the creator path's per-pool entitlement ledger

### Requirement: Pull-based claiming by the current holder
Only the current RevenueNFT owner SHALL be able to claim the hook's direct per-pool creator balance. A claim SHALL transfer the full recorded direct balance and reset it before transfer. It SHALL NOT flush a payout pot, claim a creator-path balance, or depend on plugin availability.

#### Scenario: Current holder claims direct revenue
- **WHEN** the current holder claims a non-zero direct balance
- **THEN** exactly that balance is transferred and reset to zero

#### Scenario: Non-holder direct claim is rejected
- **WHEN** a non-holder attempts a direct creator claim
- **THEN** the call reverts and all balances remain unchanged

#### Scenario: Empty direct claim is harmless
- **WHEN** the holder claims a zero direct balance
- **THEN** nothing is transferred and the call does not revert

#### Scenario: Reentrant claim cannot exceed the ledger
- **WHEN** a recipient attempts to reenter during transfer
- **THEN** no value beyond the pre-call direct balance can be transferred

#### Scenario: New direct accrual remains claimable
- **WHEN** direct creator revenue accrues after a claim
- **THEN** the current holder can claim the new amount

#### Scenario: Direct claim does not flush
- **WHEN** the holder claims direct revenue while a payout pot exists
- **THEN** the pot and all plugin carry remain unchanged

#### Scenario: Plugin failure cannot block a direct claim
- **WHEN** every selected payout plugin is failing
- **THEN** the current holder can still claim direct creator revenue

### Requirement: Transfer carries the unclaimed balance
Transferring the RevenueNFT SHALL transfer entitlement to future direct accruals, the complete unclaimed direct balance, and any unpaid creator-path entitlement. Transfer SHALL NOT settle the outgoing holder, flush a pot, or invoke a plugin.

#### Scenario: New holder claims pre-transfer direct revenue
- **WHEN** an NFT with a non-zero direct balance is transferred
- **THEN** only the new holder can claim that balance

#### Scenario: New holder receives future direct accruals
- **WHEN** direct creator value accrues after transfer
- **THEN** it is claimable by the new holder

#### Scenario: New holder receives unpaid creator-path value
- **WHEN** creator-path value remains unpaid at transfer
- **THEN** only the new holder can claim it

#### Scenario: Previous holder loses all creator claim rights
- **WHEN** the previous holder attempts either creator claim after transfer
- **THEN** the attempt is rejected

#### Scenario: Transfer performs no settlement
- **WHEN** the RevenueNFT is transferred
- **THEN** no payout pot, direct balance, or creator-path balance is paid or flushed

### Requirement: Protocol claimable balance
All quote-denominated protocol revenue SHALL accrue to one global pool-agnostic ledger, including milestone service fees, quote-fee protocol shares, and graduation protocol proceeds. The protocol SHALL additionally track the exact subset of that global ledger still backed by PoolManager quote claims: milestone service fees SHALL increase both totals, while raw-ETH-backed quote-fee and graduation revenue SHALL increase only the global ledger. Only the current configurable protocol recipient SHALL be able to pull the full global balance. A claim SHALL zero both totals before interaction, redeem exactly the captured claim-backed subset, and transfer the complete captured global balance; it SHALL NOT redeem claims backing payout pots or rely on ambient ETH reserved for another liability. The protocol administrator SHALL have no claim authority unless it is also the configured recipient. Accrual events SHALL retain pool, source, amount, and active configuration version attribution. No per-pool protocol claim path SHALL exist.

#### Scenario: Every protocol source accrues globally
- **WHEN** graduation, quote-fee collection, or milestone harvest creates protocol revenue
- **THEN** the amount increases the single global protocol ledger

#### Scenario: Multiple pools aggregate
- **WHEN** protocol revenue accrues from different pools
- **THEN** one global balance contains their sum while events preserve source pools

#### Scenario: Current recipient claims globally
- **WHEN** the configured recipient claims a non-zero balance containing raw-backed and claim-backed sources
- **THEN** both protocol counters are reset before interaction, exactly the claim-backed subset is redeemed, and the entire global balance is transferred

#### Scenario: Protocol backing classes remain explicit
- **WHEN** milestone service fees coexist with quote-fee or graduation protocol revenue
- **THEN** the claim-backed subset equals only the unredeemed service-fee value and never exceeds the global protocol ledger

#### Scenario: Protocol claim leaves payout backing intact
- **WHEN** the recipient claims while one or more payout pots remain claim-backed
- **THEN** the claim redeems no pot backing and every pot remains fully covered

#### Scenario: Unauthorized protocol claim is rejected
- **WHEN** any address other than the current recipient attempts a claim
- **THEN** the call reverts

#### Scenario: Administrator has no implicit claim right
- **WHEN** the administrator differs from the revenue recipient
- **THEN** administrator authority alone cannot claim protocol revenue

#### Scenario: Recipient update transfers unclaimed entitlement
- **WHEN** a queued recipient update executes while global revenue is unclaimed
- **THEN** only the new recipient can claim the complete existing balance

#### Scenario: No per-pool protocol claim exists
- **WHEN** protocol revenue has multiple source pools
- **THEN** callers cannot withdraw only one pool's protocol balance through a pool-scoped claim

### Requirement: Claim paths cannot drain unaccrued value
Creator and protocol claim paths SHALL transfer only their recorded ledgers. They SHALL NOT consume another party's ledger, another pool's creator revenue, payout pots, plugin carry, flusher tips, ladder inventory, burn inventory, pending locked-LP quote, or locked liquidity.

#### Scenario: Claims cannot reach ladder inventory
- **WHEN** any creator or protocol claim executes
- **THEN** undeployed inventory and deployed bands remain unchanged

#### Scenario: Claims cannot reach locked liquidity
- **WHEN** any claim executes
- **THEN** the full-range position remains unchanged

#### Scenario: Direct creator and protocol claims are isolated
- **WHEN** either ledger is claimed
- **THEN** the other ledger is unchanged

#### Scenario: Creator claims are isolated across pools
- **WHEN** one pool's holder claims
- **THEN** every other pool's creator balances are unchanged

#### Scenario: Claims cannot reach pot or carry reserves
- **WHEN** direct or global claimable balances coexist with payout pots or failed carry
- **THEN** claims leave all pot and carry value fully backed

#### Scenario: Protocol claim cannot consume creator value
- **WHEN** the global protocol recipient claims
- **THEN** no direct or creator-path entitlement is reduced

## ADDED Requirements

### Requirement: Direct creator revenue is independent of payout flushing
Direct creator revenue SHALL remain claimable without a payout flush and regardless of plugin status. Flushing or retrying a plugin SHALL NOT alter the direct creator ledger.

#### Scenario: Direct revenue is claimable while a pot is unflushed
- **WHEN** the current holder claims direct revenue while milestone value remains in the pot
- **THEN** the direct claim succeeds and the pot remains unchanged

#### Scenario: Flush leaves direct creator revenue unchanged
- **WHEN** any caller flushes the pool
- **THEN** the direct creator balance is unchanged

#### Scenario: Failed delivery leaves direct revenue unchanged
- **WHEN** a plugin delivery fails into carry
- **THEN** direct creator revenue remains fully claimable

# Capability: swap-fees

## MODIFIED Requirements

### Requirement: Default swap fee
Every pool SHALL charge the immutable template trading fee of 1% from initialization for its entire lifetime. Time, price, phase, milestone completion, fee collection, and administrative economic updates SHALL NOT change the trading fee. The pool SHALL use no dynamic-fee flag or mutable per-pool fee state.

#### Scenario: One percent applies from genesis forever
- **WHEN** swaps occur before or after any lifecycle event
- **THEN** each is charged the static 1% trading fee

#### Scenario: Time does not affect the fee
- **WHEN** equivalent swaps occur at different times
- **THEN** time since launch causes no fee difference

#### Scenario: Milestones do not affect the fee
- **WHEN** any number of milestones completes
- **THEN** the trading fee remains 1%

#### Scenario: Governance cannot change the trading fee
- **WHEN** the administrator updates configurable economic distributions
- **THEN** the pool's trading fee remains 1%

#### Scenario: Pool has no dynamic fee state
- **WHEN** a pool is inspected after initialization
- **THEN** its key has no dynamic-fee flag and no mutable fee step exists

### Requirement: Fee routing waterfall
Collected fees SHALL be routed per currency using one snapshot of the active global economic configuration. By default, quote fees SHALL route 75% to direct creator revenue and the exact remainder, initially 25%, to the global protocol ledger. The administrator MAY update the creator percentage after the configured timelock, subject to an immutable maximum of 90%; the protocol receives the exact remainder and updates SHALL apply to future collections for all pools. Token fees SHALL never reach a claimant, payout pot, payout plugin, or full-range position. Let `perBand = floor(totalSupply * ladderSupplyShareWad / WAD / coreBandCount)`, `bandCap = perBand * bandInventoryCapMultiple`, `remainingExtensions = maxFeeFundedBands - feeFundedBandsCreated`, and `freeCapacity = max(remainingExtensions * bandCap - carriedInventory - milestoneFundAccrued, 0)`. While `remainingExtensions > 0`, collection SHALL add `min(floor(tokenFees * tokenMilestoneFundShareWad / WAD), freeCapacity)` to milestone funding and SHALL burn every other collected token; once `freeCapacity` is zero, 100% SHALL burn. This capacity counts only inventory available to still-undeployed fee-funded extension bands, never core-band inventory or already deployed bands. No quote- or token-side LP fee carry SHALL exist and no collected fee SHALL compound liquidity.

#### Scenario: Default quote split is 75 25
- **WHEN** quote fees are collected under the default configuration
- **THEN** 75% credits direct creator revenue and the exact remainder credits global protocol revenue

#### Scenario: Active quote distribution applies globally
- **WHEN** a valid queued quote-creator update executes
- **THEN** subsequent collections on every pool use the new creator percentage and protocol remainder

#### Scenario: Collection uses one configuration snapshot
- **WHEN** a fee collection routes both currencies
- **THEN** one configuration version governs all routing within that operation

#### Scenario: Token fees never credit a claimant or pot
- **WHEN** token fees are collected
- **THEN** creator revenue, protocol revenue, payout pots, and plugin ledgers receive none of those tokens

#### Scenario: Collected fees never compound
- **WHEN** quote or token fees are collected after graduation
- **THEN** no amount enters the full-range position or any LP carry

#### Scenario: Routed amounts conserve each currency
- **WHEN** fees are collected
- **THEN** creator and protocol quote credits equal collected quote, while milestone funding and burn equal collected token

#### Scenario: No fee LP carry exists
- **WHEN** any collection completes
- **THEN** no quote or token balance is classified for future full-range compounding

### Requirement: Permissionless fee collection
Any address SHALL be able to collect accrued full-range fees. Collection SHALL apply one active configuration snapshot, preserve the locked position's net liquidity, and bound per-call work. Token-fee custody, milestone funding, and burning SHALL occur only on this cold path. The collector SHALL not choose destinations or retain collected value.

#### Scenario: Any address can collect
- **WHEN** an arbitrary caller triggers collection
- **THEN** accrued fees are routed under the active global configuration

#### Scenario: Net locked position is preserved
- **WHEN** collection completes
- **THEN** the full-range position's liquidity is not reduced

#### Scenario: Repeated collection is harmless
- **WHEN** collection is called repeatedly with little or no new accrual
- **THEN** work remains bounded and no caller gains protocol value

#### Scenario: Zero-accrual collection is a no-op
- **WHEN** no fees have accrued
- **THEN** nothing is routed, burned, or emitted and the call does not revert

#### Scenario: Ladder fees remain part of harvest
- **WHEN** a ladder band is harvested
- **THEN** its fees are included in gross harvest rather than this waterfall

#### Scenario: Token burning is cold-path only
- **WHEN** swaps execute without a fee-collection call
- **THEN** no token-fee burn occurs inside swap callbacks

#### Scenario: Collector cannot redirect value
- **WHEN** a third party collects fees
- **THEN** the active global distribution alone determines all destinations

### Requirement: Milestone-fund diversion of token-denominated fees
While another permitted band can use inventory, the system SHALL divert the active globally configured share of token fees to milestone inventory without performing a swap and SHALL burn the exact remainder. The default diverted share SHALL be 100%, and the immutable maximum SHALL be 100%. Quote fees SHALL never be diverted. When no future band is permitted or useful, diversion SHALL be zero and all collected token fees SHALL burn. Executed updates SHALL affect future collections for every pool without changing already routed value.

#### Scenario: Default token routing funds the whole token fee while capacity remains
- **WHEN** token fees are collected under defaults while useful ladder capacity remains
- **THEN** the whole token fee funds milestone inventory and nothing burns

#### Scenario: Active token distribution applies globally
- **WHEN** a valid queued token-fund update executes
- **THEN** future collections on every pool use the new share

#### Scenario: Quote fees are never diverted
- **WHEN** quote fees are collected
- **THEN** no quote amount enters milestone inventory

#### Scenario: Diversion causes no price impact
- **WHEN** token fees fund the ladder
- **THEN** already held tokens are reclassified without a swap

#### Scenario: Diversion stops at the cap
- **WHEN** no future permitted band can use inventory
- **THEN** no token fee enters milestone funding

#### Scenario: Diversion is clamped to remaining extension capacity
- **WHEN** the configured token-fund share exceeds positive free capacity for still-undeployed fee-funded extension bands
- **THEN** exactly that free capacity enters milestone funding and every excess token burns in the same collection

#### Scenario: Post-cap token fees burn entirely
- **WHEN** token fees are collected after the ladder cap
- **THEN** 100% of them burn regardless of the configured pre-cap share

## ADDED Requirements

### Requirement: Governed global economic configuration
The protocol SHALL maintain one active, versioned economic configuration containing milestone service-fee, quote creator, and token milestone-fund percentages. Defaults SHALL be 10%, 75%, and 100%. Protocol quote share and token burn share SHALL be exact remainders. Only the configurable protocol administrator SHALL queue or cancel updates, and executed updates SHALL affect future harvests and fee collections for every existing and future pool. Immutable validation SHALL enforce service fee at most 20%, quote creator at most 90%, and token milestone funding at most 100%. Trading fee, graduation split, and all post-graduation LP compounding SHALL remain outside this configuration.

#### Scenario: Default global configuration is published
- **WHEN** the protocol is deployed
- **THEN** defaults are 10% harvest service fee, 75 25 quote routing, and 100 0 pre-cap token routing

#### Scenario: Valid update affects every pool prospectively
- **WHEN** a queued economic update executes
- **THEN** every pool uses it for later operations without repartitioning prior accruals

#### Scenario: Service-fee cap is enforced
- **WHEN** an update proposes more than 20% harvest service fee
- **THEN** it is rejected

#### Scenario: Quote creator cap is enforced
- **WHEN** an update proposes more than 90% creator share
- **THEN** it is rejected and the protocol remainder cannot fall below 10%

#### Scenario: Token-fund cap is enforced
- **WHEN** an update proposes more than 100% pre-cap milestone funding
- **THEN** it is rejected

#### Scenario: Exact cap values are accepted
- **WHEN** every updated value sits exactly at its immutable bound
- **THEN** the update can execute after its delay

#### Scenario: Prior accrual is not repartitioned
- **WHEN** configuration changes after a pot or claimable balance has accrued
- **THEN** that recorded value remains unchanged

#### Scenario: Uncollected fees use collection-time configuration
- **WHEN** swap fees accrue before an update but are collected afterward
- **THEN** the configuration active at collection governs their routing

#### Scenario: Trading fee remains immutable
- **WHEN** any economic configuration update executes
- **THEN** all pool trading fees remain 1%

## REMOVED Requirements

### Requirement: Milestone-completion fee schedule
**Reason**: Trading fees are static at 1% for the pool lifetime; milestone-driven dynamic fee steps and their flag are removed.

**Migration**: Delete fee-step state, events, update calls, and threshold tests; replace them with static-fee tests across arbitrary milestone counts and governance updates.

# Capability: token-launch

## MODIFIED Requirements

### Requirement: Signed-config launch with permissionless relay
The protocol's trusted operator SHALL sign the complete EIP-712 launch configuration, including deadline and exact 256-bit payout plan, and any address SHALL be able to relay it. A creator MAY launch directly without a signature. The recorded creator SHALL be the creator declared in the configuration — vouched for by the trusted operator on the relayed path, or proven as the sender on the direct path — never the relayer. The trusted operator SHALL be stored on chain and replaceable only through typed governance; a signature that does not recover to the current trusted operator SHALL be rejected. Altering any field or payout-plan bit SHALL invalidate the signature. The configuration SHALL contain no harvest percentages, preset name, dev-buy vesting duration, or active governance-version snapshot. Existing replay and deadline protections SHALL remain.

#### Scenario: Relayer launches for the operator
- **WHEN** any address submits a valid operator-signed configuration before its deadline
- **THEN** one token and pool launch with the declared creator recorded as creator

#### Scenario: Only the trusted operator can sign launches
- **WHEN** a relayed launch carries a signature recovering to any address other than the on-chain trusted operator
- **THEN** the launch is rejected

#### Scenario: Operator rotation is governance-configurable
- **WHEN** the administrator schedules and executes a trusted-operator replacement
- **THEN** future signed launches verify against the new operator and completed launches are unaffected

#### Scenario: Creator launches directly
- **WHEN** the creator submits the same configuration without a signature
- **THEN** launch succeeds with the same deterministic identity

#### Scenario: Relayer cannot alter any field
- **WHEN** a relayer changes launch metadata, supply, dev-buy share, deadline, or another signed field
- **THEN** signature verification fails

#### Scenario: Relayer cannot alter a plan bit
- **WHEN** a relayer flips any payout-plan bit
- **THEN** signature verification fails

#### Scenario: Replay is rejected
- **WHEN** an identical signed launch is submitted again
- **THEN** deterministic deployment collision or replay protection rejects it

#### Scenario: Expired signature is rejected
- **WHEN** a relayed launch occurs after its signed deadline
- **THEN** launch reverts

#### Scenario: Launch identity is isolated
- **WHEN** distinct launches complete
- **THEN** each pool, token, plan, and accounting state remains isolated

### Requirement: Per-launch configuration
Per-launch configuration SHALL contain token metadata, the protocol-pinned total supply, optional creator dev-buy share capped at 10%, payout-plan bitset, and deadline. Supply SHALL equal the protocol constant, and any other value SHALL be rejected, because the seeded positions' bounds are derived from the graduation valuation that supply produces. All geometry, the static 1% trading fee, graduation split, and work caps SHALL remain protocol-defined. No launch SHALL configure harvest percentages, vesting duration, economic-governance values, or preset name. Plan validation SHALL enforce registered active payout roles, fixed takes totaling at most one whole, and no more than eight enabled plugins. An empty plan and a plan totaling exactly one whole SHALL be valid.

#### Scenario: Geometry is not configurable
- **WHEN** a launch is constructed
- **THEN** it contains no band, curve, fee, or work-cap override

#### Scenario: Supply is the protocol constant
- **WHEN** a launch declares a total supply other than the pinned constant
- **THEN** launch is rejected before the token deploys

#### Scenario: Harvest percentages are not configurable
- **WHEN** a creator chooses payout behavior
- **THEN** they can select registry bits but cannot supply destination percentages

#### Scenario: Unknown or suspended plan bit is rejected
- **WHEN** a plan selects a nonexistent or suspended entry
- **THEN** launch reverts

#### Scenario: Enabled takes above one whole are rejected
- **WHEN** selected immutable takes total more than 100%
- **THEN** launch reverts

#### Scenario: More than eight plugins is rejected
- **WHEN** a plan selects nine or more payout entries
- **THEN** launch reverts

#### Scenario: Empty plan is accepted
- **WHEN** no payout bit is set
- **THEN** launch succeeds and the creator is the implicit full remainder destination

#### Scenario: Exact whole plan is accepted
- **WHEN** at most eight selected takes total exactly 100%
- **THEN** launch succeeds

#### Scenario: Preset names are absent
- **WHEN** a preset is used by a frontend
- **THEN** only the resulting bitset enters signed launch data

### Requirement: Token deployment and supply allocation
The system SHALL deploy one standard ERC20 via CREATE2 with a salt derived from the deadline-independent configuration hash and creator identity. The configuration hash SHALL bind the payout-plan bitset, so a different plan yields a different predicted address while re-signing only with a fresh deadline preserves it. The initial supply SHALL be minted to the hook for protocol allocation, except tokens bought by an immediate creator dev buy SHALL be transferred to the creator before launch returns. No post-launch mint capability SHALL exist.

#### Scenario: Protocol initially receives the full minted supply
- **WHEN** token deployment occurs
- **THEN** the hook receives the fixed total supply before genesis allocation and optional dev-buy execution

#### Scenario: Address is predictable
- **WHEN** an observer knows the configuration and creator
- **THEN** they can derive the token address before launch

#### Scenario: Different creator cannot occupy the address
- **WHEN** otherwise identical data declares a different creator
- **THEN** that configuration's token address differs

#### Scenario: Re-signing preserves the address
- **WHEN** only the deadline and signature are refreshed
- **THEN** the predicted token address is unchanged

#### Scenario: Different payout plan changes the address
- **WHEN** any payout-plan bit changes
- **THEN** the predicted token address changes

#### Scenario: Supply is fixed after launch
- **WHEN** any caller attempts additional minting
- **THEN** it is rejected

#### Scenario: Token remains standard ERC20
- **WHEN** holders transfer, approve, or query the token
- **THEN** standard ERC20 behavior applies without transfer restrictions or taxes

### Requirement: Hook address encodes required permissions
The hook address SHALL encode exactly the lifecycle callback permissions required by the launchpad: before-initialize, after-initialize, before-swap, after-swap, before-add-liquidity, and before-remove-liquidity. No dynamic-fee flag SHALL be part of pool configuration or treated as a hook-address permission.

### Requirement: Phase-gated liquidity admission
While a pool is in its bonding-curve phase, only the protocol SHALL add or remove liquidity: the curve, and later the ladder, are the mechanism, and no external deposit may sit outside the simulation that sizes protocol positions. After graduation the pool SHALL admit external liquidity — any address MAY add positions for itself and remove or collect on them like any Uniswap v4 position. Protocol-authored positions SHALL remain protocol-owned on both phases: v4 keys positions to their owner, so no third party can modify, collect on, or remove the hook's curve, band, or full-range positions, and the full-range principal SHALL remain permanently locked by the structural absence of any removal path.

#### Scenario: External liquidity is rejected on the curve
- **WHEN** an external address attempts to add or remove liquidity while the pool is in its bonding-curve phase
- **THEN** the attempt is rejected

#### Scenario: Graduated pools accept external liquidity
- **WHEN** an external address adds a position of its own after graduation and later removes or collects on it
- **THEN** every step succeeds like an ordinary Uniswap v4 position

#### Scenario: Protocol positions are not externally reachable
- **WHEN** an external address targets a protocol position's range and salt after graduation
- **THEN** v4 resolves the attempt to the caller's own position space, and the protocol position and its accrued fees are untouched

#### Scenario: Deployed hook has required callback flags
- **WHEN** the hook is deployed and a pool initializes
- **THEN** its address contains every required callback permission

#### Scenario: Pool has no dynamic-fee flag
- **WHEN** a launched pool key is inspected
- **THEN** it contains the static template fee without a dynamic flag

#### Scenario: Pool initialization is restricted
- **WHEN** an external party attempts unauthorized initialization against the hook
- **THEN** initialization reverts

### Requirement: Pool initialization
The pool SHALL initialize at the level derived from total supply and the anchored opening FDV, using the immutable static 1% template trading fee without a dynamic-fee flag. The launch transaction SHALL leave the first curve position live and the pool tradable.

#### Scenario: Starting price matches anchored FDV
- **WHEN** launch completes
- **THEN** the initial level values total supply at the anchored opening FDV

#### Scenario: Pool uses static one percent
- **WHEN** the pool key is created
- **THEN** its fee is the static 1% template value

#### Scenario: Pool is tradable at launch
- **WHEN** launch returns
- **THEN** the first curve position exists and swaps can execute

### Requirement: Optional creator dev buy
A creator-direct launch MAY execute a dev buy against the bonding curve on ordinary buyer terms, capped at 10% of total supply. Every purchased token SHALL transfer to the creator before launch returns. A relayed launch SHALL execute no dev buy and SHALL leave that share as curve inventory. The launch configuration and pool state SHALL contain no vesting duration, schedule, releasable balance, or release entry point.

#### Scenario: Dev buy consumes curve inventory
- **WHEN** a creator-direct launch includes a dev buy
- **THEN** it purchases from curve inventory and moves price on ordinary terms

#### Scenario: Dev buy is capped at ten percent
- **WHEN** the requested share exceeds 10% of supply
- **THEN** launch reverts

#### Scenario: Dev buy requires creator transaction
- **WHEN** a relayer submits a configuration with a non-zero dev-buy share
- **THEN** no dev buy executes and the share remains curve inventory

#### Scenario: No dev buy is the default
- **WHEN** dev-buy share is zero
- **THEN** no creator purchase occurs

#### Scenario: Dev buy is observable
- **WHEN** a dev buy executes
- **THEN** events record tokens acquired, quote spent, and creator recipient

#### Scenario: Tokens are delivered fully at launch
- **WHEN** a creator dev buy succeeds
- **THEN** all purchased tokens are in the creator's balance before launch returns

#### Scenario: No vesting state is created
- **WHEN** any launch completes
- **THEN** no dev-buy tokens remain reserved for later release

## REMOVED Requirements

### Requirement: Dev buy vesting
**Reason**: Creator dev-buy tokens are delivered fully during launch; vesting configuration, custody, math, views, and release actions are removed.

**Migration**: Remove vesting fields and release interfaces from signed data, storage, fixtures, deployment scripts, tests, events, and documentation.
