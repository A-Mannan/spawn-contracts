# Spawn — Integration Handoff (frontend & backend)

Start here. This bundle is everything a frontend or backend/indexer team needs to begin
integrating with the Spawn launchpad contracts.

## Where to start

| Order | Read | Why |
| --- | --- | --- |
| 1 | `docs/technical/integration.md` | **The primary handoff**: contract map, `level = -tick` orientation, launch flow with the EIP-712/viem snippet, token-address prediction, dev-buy quote math, quoting/simulation, value flows, claim matrix, keeper batching, the complete hook event catalog, and the constants sheet |
| 2 | `SPECS.md` | The normative requirements (consolidated verbatim from the repo's openspec deltas) — what the protocol guarantees, requirement by requirement, with the named scenarios the test suite pins |
| 3 | `abi/*.json` | The curated contract ABIs (10 files). Ship **only `MilestoneHook`'s ABI to signers** — the satellite ABIs exist for source verification only; their entries revert when called directly |
| 4 | `backend/BACKEND_GUIDE.md` | **Backend/indexer only**: Postgres schema, event tables, chart pipelines, streaming contract — plus the trusted-signer operations note you must implement before accepting relay launches |
| 5 | `docs/technical/architecture.md` → `lifecycle.md` → `economics-and-governance.md` | System shape, state machine, and the exact economic numbers |
| 6 | `docs/user/*` | Product behavior in plain language — useful for UX copy and edge-case handling |

`docs/SUMMARY.md` is the full index of the bundle.

## Current economics (revision summary — everything below is new in this handoff)

- **Supply is pinned to 1,000,000,000 tokens.** A launch declaring any other supply reverts
  (`SupplyNotFixed`). Split: **25% bonding curve (250M) / 10% milestone ladder (100M, 22 bands) /
  65% graduation LP share (650M)**.
- **Opening FDV 2 ETH (~$5,000 at $2,500/ETH); graduation at ~4x (~$20,000 FDV).** The bonding
  curve spans two market-cap doublings (13,862 levels).
- **Graduation split: 10% protocol / 20% LP seed / 70% creator** (of quote proceeds).
- **Ladder: 22 core bands, decaying steps.** Band `i+1` starts `max(2235, 6932 − 391·i)` levels
  above band `i`: a **2x** first multiple decaying to the **1.2504x** floor (2,235 levels), 447-level
  bands. Top ≈ 2,900x graduation (**~$58M**); up to 30 fee-funded extensions continue at the floor.
- **Bounded full-range position + wall at graduation.** The 20% LP seed is ETH-limited into the
  `$5,100 → $150B` FDV range (~72.77M of the 650M tokens; the `$5,100` bound is a hard price floor —
  nothing provides liquidity below it). The remaining ~577.23M tokens become a **single-sided,
  token-only wall** over the 880,000 levels above graduation: permanent buy-side backing that a
  frontend can treat as deep inventory that only sells a thin layer per price move.
- **Token fees: 100% to the milestone fund by default** (capped at 100%, still clamped by remaining
  fee-funded extension capacity — at zero capacity 100% burns). Quote fees unchanged: 75% creator /
  25% protocol.

## Four facts that change how you build

1. **No addresses exist yet.** Nothing is deployed. When deployment happens, `script/Deploy.s.sol`
   writes `deployments/<chainId>.json` — every address, the hook salt, the canonical payout plan,
   and the template + economics snapshot. **Consume addresses only from that manifest**; never
   hardcode one. Until then, build against the ABIs and the fork tests.
2. **The EIP-712 launch domain is `SpawnLaunchpad`, version `"1"`**, with the hook address as the
   verifying contract. Any signature code using a different domain name produces digests the
   protocol rejects. Cross-check client-side digests against `LaunchSupport.launchDigest(config, hook)`.
3. **Relay launches need the backend's trusted signer.** Creators never sign; the protocol's
   on-chain `trustedOperator` key — operated by the backend — signs every relayed `LaunchConfig`.
   **The backend must provision, fund, HSM/Vault-back, and monitor this key before accepting relay
   launches** (see `backend/BACKEND_GUIDE.md` §6.1). A signature from any other key reverts
   (`UnauthorizedLaunchSigner`); setting the operator to zero disables relayed launches entirely.
   Key rotation runs through typed governance only.
4. **There is no protocol swap-and-flush router.** "Trade, then flush" composes via the v4 SDK plus
   a `flush(poolId)` call, or Multicall3 batching on Base (`0xcA11bde05977b3631167028862bE2a173976CA11`,
   `aggregate3`) — see integration guide sections 5.3 and 7.3.

## Ground rules that hold everywhere

- The pool is **ETH vs token, static 1% fee, tick spacing 1**; buys pay the fee in ETH, sells in token.
- **Nobody can provide liquidity** except the protocol — until graduation the hook rejects every
  third-party deposit/withdrawal; after graduation third parties may LP their own positions, while
  the protocol's full-range and wall positions stay unreachable and code-locked.
- Convert ticks to the protocol's `level = -tick` exactly once at the pool boundary; all display
  math is level space (`FDV = totalSupply × 1.0001^level`).
- The `Graduated` event carries both seeded liquidities (`fullRangeLiquidity`, `wallLiquidity`);
  pool bounds are derived constants, not reads.
- Zero-amount claims and empty flushes are **no-op successes**, so batch calls with
  `aggregate3.allowFailure = false` are safe.

## Canonical sources

- Repository: `github.com/A-Mannan/spawn-contracts` (branch `main`)
- Normative specs: `openspec/changes/add-payout-plugins/specs/` in that repo; the docs bundle mirrors
  `docs/` on `main`. If this bundle and the repo disagree, the repo wins.
- The published docs site (GitBook) carries the same content once synced.
